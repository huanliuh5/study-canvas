var util = {

    // 角度转换为弧度
    angleToRadian: function( angle ) {
        return Math.PI / 180 * angle;
    }
};